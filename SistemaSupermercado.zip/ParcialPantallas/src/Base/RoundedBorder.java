/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Base;

/**
 *
 * @author gonza
 */
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.geom.RoundRectangle2D;
import javax.swing.border.AbstractBorder;

public class RoundedBorder extends AbstractBorder {
    private final int radius;
    
    // Constructor que recibe el radio de las esquinas
    public RoundedBorder(int radius) {
        this.radius = radius;
    }
    
 

    // Método que dibuja el borde
    @Override
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        super.paintBorder(c, g, x, y, width, height);
        
        // Configura el renderizado
        java.awt.Graphics2D g2 = (java.awt.Graphics2D) g;
        g2.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING, 
                            java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Define el color y el estilo del borde
        g2.setColor(c.getForeground().darker()); // Puedes cambiar el color aquí
        g2.draw(new RoundRectangle2D.Double(x, y, width - 1, height - 1, radius, radius));
    }

    // Define los márgenes internos para que el texto no toque el borde
    @Override
    public Insets getBorderInsets(Component c) {
        // Ajusta los márgenes según el radio
        return new Insets(radius/2, radius, radius/2, radius);
    }
    
    // Define los márgenes internos para que el texto no toque el borde (otra sobrecarga)
    @Override
    public Insets getBorderInsets(Component c, Insets insets) {
        insets.left = insets.right = radius;
        insets.top = insets.bottom = radius/2;
        return insets;
    }
}
