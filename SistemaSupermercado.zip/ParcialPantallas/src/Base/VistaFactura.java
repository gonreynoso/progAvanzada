/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Base;

import javax.swing.table.DefaultTableModel;
import java.io.File;
import java.io.FileWriter;
import javax.swing.JFileChooser;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import java.util.Date;
/**
 *
 * @author nahui
 */
public class VistaFactura extends javax.swing.JFrame {
    
    String nombre, apellido, telefono;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VistaFactura.class.getName());

    /**
     * Creates new form VistaFactura
     */
    public VistaFactura(DefaultTableModel modelo, String totalGeneral, String metodoPago, 
                        String nombre, String apellido, String telefono, boolean hayDescuento) {
        initComponents();
        this.setLocationRelativeTo(null);
        
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        txtNombreCliente.setText(nombre + " " + apellido + "!");
        // Llamamos al método que genera el ticket
        generarTicketDetallado(modelo, totalGeneral, metodoPago, hayDescuento);
    }

    private void generarTicketDetallado(DefaultTableModel modelo, String totalGeneral, String metodo, boolean descuento) {
        StringBuilder ticket = new StringBuilder();
        
        // 1. FECHA Y HORA
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        String fechaHora = sdf.format(new Date());

        // ENCABEZADO
        ticket.append("==================================================\n");
        ticket.append("               TICKET DE COMPRA                   \n");
        ticket.append("==================================================\n");
        ticket.append("Fecha: ").append(fechaHora).append("\n");
        ticket.append("--------------------------------------------------\n");
        ticket.append("DATOS DEL CLIENTE:\n");
        ticket.append("Nombre:   ").append(nombre).append(" ").append(apellido).append("\n");
        ticket.append("Teléfono: ").append(telefono).append("\n");
        ticket.append("--------------------------------------------------\n");
        ticket.append("Método de Pago: ").append(metodo).append("\n");
        ticket.append("==================================================\n");
        
        // CABECERA DE TABLA
        // Desc = Descripción, Cant = Cantidad, P.U = Precio Unitario
        // Dto = Descuento, Final = Monto Total del producto
        ticket.append(String.format("%-12s %4s %8s %5s %9s\n", "PRODUCTO", "CANT", "PRECIO", "DTO", "TOTAL"));
        ticket.append("--------------------------------------------------\n");

        // RECORRER PRODUCTOS
        for (int i = 0; i < modelo.getRowCount(); i++) {
            // ASUMO ESTE ORDEN EN TU TABLA: 
            // 0=Nombre, 1=PrecioUnitario, 2=Cantidad, 3=SubtotalBase
            String prod = modelo.getValueAt(i, 0).toString();
            String precioUni = modelo.getValueAt(i, 1).toString(); 
            String cantidad = modelo.getValueAt(i, 2).toString();
            String subtotalStr = modelo.getValueAt(i, 3).toString();

            // Lógica de Descuento y Totales
            String textoDesc = "0%";
            String montoFinalStr = subtotalStr; // Por defecto es igual al subtotal

            if (descuento) {
                textoDesc = "10%";
                // Intentamos calcular el monto con descuento
                try {
                    // Quitamos el signo $ si existe para poder multiplicar
                    String limpio = subtotalStr.replace("$", "").replace(" ", "");
                    double montoBase = Double.parseDouble(limpio);
                    double montoConDesc = montoBase * 0.90; // Aplicamos 10% off
                    montoFinalStr = "$" + String.format("%.0f", montoConDesc); // Sin decimales
                } catch (Exception e) {
                    montoFinalStr = subtotalStr; // Si falla el calculo, dejamos el original
                }
            } else {
                if(!montoFinalStr.contains("$")) montoFinalStr = "$" + montoFinalStr;
            }

            // Cortar nombre largo
            if (prod.length() > 12) prod = prod.substring(0, 12);

            // AGREGAR FILA AL TICKET
            ticket.append(String.format("%-12s %4s %8s %5s %9s\n", 
                    prod, cantidad, "$" + precioUni, textoDesc, montoFinalStr));
        }

        ticket.append("--------------------------------------------------\n");
        ticket.append(" TOTAL A PAGAR:              ").append(totalGeneral).append("\n");
        ticket.append("==================================================\n");

        txtResumen.setText(ticket.toString());
        txtResumen.setCaretPosition(0);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtGraciasCompra = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtResumen = new javax.swing.JTextArea();
        btnDescargar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        txtNombreCliente = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        txtGraciasCompra.setEditable(false);
        txtGraciasCompra.setBackground(new java.awt.Color(255, 255, 255));
        txtGraciasCompra.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        txtGraciasCompra.setForeground(new java.awt.Color(0, 0, 0));
        txtGraciasCompra.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtGraciasCompra.setText("¡Gracias por tu compra,");
        txtGraciasCompra.setBorder(null);
        txtGraciasCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtGraciasCompraActionPerformed(evt);
            }
        });

        txtResumen.setEditable(false);
        txtResumen.setColumns(20);
        txtResumen.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        txtResumen.setRows(5);
        txtResumen.setBorder(null);
        jScrollPane1.setViewportView(txtResumen);

        btnDescargar.setBackground(new java.awt.Color(0, 153, 0));
        btnDescargar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnDescargar.setText("Descargar Factura");
        btnDescargar.setBorder(null);
        btnDescargar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDescargarActionPerformed(evt);
            }
        });

        btnSalir.setBackground(new java.awt.Color(102, 0, 0));
        btnSalir.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnSalir.setText("Salir");
        btnSalir.setBorder(null);
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        txtNombreCliente.setEditable(false);
        txtNombreCliente.setBackground(new java.awt.Color(255, 255, 255));
        txtNombreCliente.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        txtNombreCliente.setForeground(new java.awt.Color(0, 0, 0));
        txtNombreCliente.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtNombreCliente.setBorder(null);
        txtNombreCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreClienteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(171, 171, 171)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(284, 284, 284)
                        .addComponent(btnDescargar, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(txtGraciasCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(66, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(87, 87, 87)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtGraciasCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnDescargar, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtGraciasCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtGraciasCompraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtGraciasCompraActionPerformed

    private void btnDescargarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDescargarActionPerformed
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Guardar Factura como...");
        
        // Nombre sugerido por defecto
        fileChooser.setSelectedFile(new File("Comprobante_Compra.txt"));

        // Abrir ventana de guardar
        int userSelection = fileChooser.showSaveDialog(this);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            try {
                File fileToSave = fileChooser.getSelectedFile();
                String path = fileToSave.getAbsolutePath();
                
                // Asegurar extensión .txt
                if (!path.endsWith(".txt")) {
                    path += ".txt";
                }
                
                // Escribir archivo
                FileWriter writer = new FileWriter(path);
                writer.write(txtResumen.getText());
                writer.close();
                
                JOptionPane.showMessageDialog(this, "¡Factura descargada con éxito!");
                
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error al guardar: " + e.getMessage());
            }
        }
    
    }//GEN-LAST:event_btnDescargarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnSalirActionPerformed

    private void txtNombreClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreClienteActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
       try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VistaFactura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            // ESTA ES LA LÍNEA QUE ARREGLA EL ERROR:
            // Le pasamos datos falsos ("new DefaultTableModel()", "0", etc.) 
            // solo para que Java deje de quejarse y te deje compilar.
            new VistaFactura(new DefaultTableModel(), "0", "Test", "Nom", "Ape", "Tel", false).setVisible(true);
        });
    }



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDescargar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtGraciasCompra;
    private javax.swing.JTextField txtNombreCliente;
    private javax.swing.JTextArea txtResumen;
    // End of variables declaration//GEN-END:variables

}



