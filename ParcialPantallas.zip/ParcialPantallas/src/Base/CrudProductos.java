/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Base;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class CrudProductos extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(CrudProductos.class.getName());

    public CrudProductos() {
        initComponents();
        
         javax.swing.table.DefaultTableModel modeloProductos = (javax.swing.table.DefaultTableModel) jTableProductos.getModel();
        
        modeloProductos.setRowCount(0);
        
        modeloProductos.addRow(new Object[]{104, "Alfajor Guaymallen", 1000, 200});
        modeloProductos.addRow(new Object[]{105, "Jugo Naranja Baggio (L)", 850, 75});
        modeloProductos.addRow(new Object[]{106, "Chicle Bazooka", 50, 500});
        modeloProductos.addRow(new Object[]{107, "Cerveza Quilmes (L)", 1800, 40});
        modeloProductos.addRow(new Object[]{108, "Galletitas Oreo", 950, 60});
        modeloProductos.addRow(new Object[]{109, "Mayonesa Hellmann's (Kg)", 3200, 25});
        modeloProductos.addRow(new Object[]{110, "Pan Lactal Grande", 1500, 35});
        modeloProductos.addRow(new Object[]{111, "Leche Entera Sachet", 1100, 90});
        modeloProductos.addRow(new Object[]{112, "Café Instantáneo (50g)", 2500, 55});
        modeloProductos.addRow(new Object[]{113, "Arroz Gallo Oro (Kg)", 900, 120});
        modeloProductos.addRow(new Object[]{114, "Fideos Secos Matarazzo", 800, 150});
        modeloProductos.addRow(new Object[]{115, "Shampoo Sedal (400ml)", 2800, 30});
        modeloProductos.addRow(new Object[]{116, "Dentífrico Colgate", 1200, 80});
        modeloProductos.addRow(new Object[]{117, "Atún La Campagnola", 1900, 45});
        modeloProductos.addRow(new Object[]{118, "Aceite Girasol (L)", 2200, 70});
        
        jTextFieldCodigo.setEditable(false);
        
        // 2. Agregar el listener para manejar la selección de filas y habilitar/deshabilitar botones
        jTableProductos.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int filaSeleccionada = jTableProductos.getSelectedRow();

                if (filaSeleccionada != -1) {
                    // Si una fila está seleccionada (MODO EDICIÓN)
                    cargarDatosEnCampos();
                    jButtonGuardar.setEnabled(false); // ❌ Deshabilita Crear
                    jButtonModificar.setEnabled(true); // ✅ Habilita Modificar
                    jButtonEliminar.setEnabled(true); // ✅ Habilita Eliminar

                } else {
                    // Si ninguna fila está seleccionada (MODO CREACIÓN/LIMPIO)
                    jButtonGuardar.setEnabled(true); // ✅ Habilita Crear
                    jButtonModificar.setEnabled(false); // ❌ Deshabilita Modificar
                    jButtonEliminar.setEnabled(false); // ❌ Deshabilita Eliminar
                    // NOTA: No llamamos a limpiarCampos() aquí para evitar ciclos infinitos, 
                    // la limpieza la manejamos con el botón Limpiar.
                }
            }
        });
        
        // 3. Inicializar el estado de los botones al cargar el formulario
        jButtonModificar.setEnabled(false); 
        jButtonEliminar.setEnabled(false);
        // El botón jButtonGuardar (Crear) estará habilitado por defecto.
        
        this.setLocationRelativeTo(null);
        this.setResizable(false);
         

    }

    
    // -------------------------------------------------------------------------
    // --- Métodos Adicionales para el CRUD y Limpieza
    // -------------------------------------------------------------------------

    // Método para limpiar los campos de texto
    private void limpiarCampos() {
        jTextFieldCodigo.setText("");
        jTextFieldNombre.setText("");
        jTextFieldPrecio.setText("");
        jTextFieldStock.setText("");
        // Deseleccionar la fila de la tabla
        jTableProductos.clearSelection();
        
        // 👇 NUEVA LÓGICA: Volver a Modo Creación
        jButtonGuardar.setEnabled(true); // ✅ Habilita Crear
        jButtonModificar.setEnabled(false); // ❌ Deshabilita Modificar
        jButtonEliminar.setEnabled(false); // ❌ Deshabilita Eliminar
    }
    
    // Método para cargar datos de la fila seleccionada a los campos
    private void cargarDatosEnCampos() {
        int filaSeleccionada = jTableProductos.getSelectedRow();
        DefaultTableModel modelo = (DefaultTableModel) jTableProductos.getModel();
        
        if (filaSeleccionada >= 0) {
            // Asumiendo el orden de las columnas: 0=Codigo, 1=Nombre, 2=Precio, 3=Stock
            // Se convierten a String para que funcionen con setText()
            jTextFieldCodigo.setText(modelo.getValueAt(filaSeleccionada, 0).toString());
            jTextFieldNombre.setText(modelo.getValueAt(filaSeleccionada, 1).toString());
            jTextFieldPrecio.setText(modelo.getValueAt(filaSeleccionada, 2).toString());
            jTextFieldStock.setText(modelo.getValueAt(filaSeleccionada, 3).toString());
        }
    }
    
    

    /**
     * Recorre la tabla para encontrar el código de producto más alto
     * y devuelve el siguiente código disponible.
     * @return int El nuevo código de producto.
     */
    private int obtenerNuevoCodigo() {
        javax.swing.table.DefaultTableModel modelo = (javax.swing.table.DefaultTableModel) jTableProductos.getModel();
        int maxCodigo = 0;

        // La columna del Código es la columna 0
        final int COLUMNA_CODIGO = 0;

        // Recorrer todas las filas de la tabla
        for (int i = 0; i < modelo.getRowCount(); i++) {
            try {
                // Obtener el valor de la columna 0 (Código) y convertirlo a entero
                int codigoActual = (int) modelo.getValueAt(i, COLUMNA_CODIGO);
                if (codigoActual > maxCodigo) {
                    maxCodigo = codigoActual;
                }
            } catch (Exception e) {
                // Manejar posibles errores si el dato en la columna 0 no es un entero
                logger.severe("Error al leer código de fila " + i + ": " + e.getMessage());
            }
        }

        // Si la tabla estaba vacía (maxCodigo = 0), el primer código será 1. 
        // Si no, será el máximo código + 1.
        return maxCodigo + 1;
    }
 
    
    
    // -------------------------------------------------------------------------
    // --- Manejadores de Eventos (Event Handlers)
    // -------------------------------------------------------------------------
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableProductos = new javax.swing.JTable();
        jLabelPrecio = new javax.swing.JLabel();
        jLabelTitle = new javax.swing.JLabel();
        jTextFieldPrecio = new javax.swing.JTextField();
        jTextFieldStock = new javax.swing.JTextField();
        jTextFieldNombre = new javax.swing.JTextField();
        jTextFieldCodigo = new javax.swing.JTextField();
        jLabelStock = new javax.swing.JLabel();
        jLabelCodigo = new javax.swing.JLabel();
        jLabelNombre = new javax.swing.JLabel();
        jButtonGuardar = new javax.swing.JButton();
        jButtonLimpiar = new javax.swing.JButton();
        jButtonEliminar = new javax.swing.JButton();
        jButtonModificar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTableProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Codigo", "Nombre", "Precio", "Stock"
            }
        ));
        jScrollPane1.setViewportView(jTableProductos);

        jLabelPrecio.setText("Precio");

        jLabelTitle.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabelTitle.setText("GESTION DE PRODUCTOS");

        jTextFieldCodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldCodigoActionPerformed(evt);
            }
        });

        jLabelStock.setText("Stock");

        jLabelCodigo.setText("Codigo");

        jLabelNombre.setText("Nombre");

        jButtonGuardar.setBackground(new java.awt.Color(51, 204, 0));
        jButtonGuardar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonGuardar.setForeground(new java.awt.Color(0, 0, 0));
        jButtonGuardar.setText("CREAR ");
        jButtonGuardar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGuardarActionPerformed(evt);
            }
        });

        jButtonLimpiar.setBackground(new java.awt.Color(0, 204, 204));
        jButtonLimpiar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonLimpiar.setForeground(new java.awt.Color(0, 0, 0));
        jButtonLimpiar.setText("LIMPIAR");
        jButtonLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonLimpiarActionPerformed(evt);
            }
        });

        jButtonEliminar.setBackground(new java.awt.Color(255, 51, 51));
        jButtonEliminar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonEliminar.setForeground(new java.awt.Color(0, 0, 0));
        jButtonEliminar.setText("BORRAR");
        jButtonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEliminarActionPerformed(evt);
            }
        });

        jButtonModificar.setBackground(new java.awt.Color(255, 153, 0));
        jButtonModificar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonModificar.setForeground(new java.awt.Color(0, 0, 0));
        jButtonModificar.setText("EDITAR");
        jButtonModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonModificarActionPerformed(evt);
            }
        });

        btnVolver.setText("Atrás");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 876, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelCodigo)
                            .addComponent(jTextFieldCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButtonGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(291, 291, 291)
                                .addComponent(jButtonEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(62, 62, 62)
                                .addComponent(jButtonLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(226, 226, 226)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jTextFieldNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabelNombre))
                                        .addGap(65, 65, 65)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabelPrecio)
                                            .addComponent(jTextFieldPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(62, 62, 62)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabelStock)
                                            .addComponent(jTextFieldStock, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(jButtonModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(300, 300, 300)
                        .addComponent(jLabelTitle)))
                .addContainerGap(35, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabelTitle)
                .addGap(42, 42, 42)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(53, 53, 53)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelCodigo)
                    .addComponent(jLabelStock)
                    .addComponent(jLabelNombre)
                    .addComponent(jLabelPrecio))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextFieldCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextFieldPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTextFieldNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTextFieldStock, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(70, 70, 70)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed

        MenuEmpleado empleado = new MenuEmpleado();


        empleado.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    private void jButtonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGuardarActionPerformed
        // Implementación de Crear (Create)
    javax.swing.table.DefaultTableModel modelo = (javax.swing.table.DefaultTableModel) jTableProductos.getModel();
    
    // 1. OBTENER EL CÓDIGO AUTOMÁTICAMENTE
    int nuevoCodigo = obtenerNuevoCodigo();
    
    // 2. Obtener datos de los campos de texto
    String nombre = jTextFieldNombre.getText();
    String precioStr = jTextFieldPrecio.getText();
    String stockStr = jTextFieldStock.getText();

    // 🌟 CORRECCIÓN CLAVE: 3. Validación solo para Nombre, Precio y Stock
    if (nombre.isEmpty() || precioStr.isEmpty() || stockStr.isEmpty()) {
        // Rellenamos el campo de código ANTES de mostrar el error, para que el usuario sepa que está funcionando.
        jTextFieldCodigo.setText(String.valueOf(nuevoCodigo)); 
        JOptionPane.showMessageDialog(this, "El Nombre, Precio y Stock deben estar llenos.", "Error de Creación", JOptionPane.ERROR_MESSAGE);
        return;
    }

    try {
        // Intentar parsear a tipos numéricos
        double precio = Double.parseDouble(precioStr);
        int stock = Integer.parseInt(stockStr);
        
        // 4. Crear una nueva fila y agregarla al modelo, USANDO EL CÓDIGO GENERADO
        modelo.addRow(new Object[]{nuevoCodigo, nombre, precio, stock});
        
        // 5. Notificar al usuario y limpiar campos
        JOptionPane.showMessageDialog(this, "Producto creado exitosamente con Código: " + nuevoCodigo, "Creación Exitosa", JOptionPane.INFORMATION_MESSAGE);
        limpiarCampos();
        
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "El Precio y Stock deben ser números válidos.", "Error de Formato", JOptionPane.ERROR_MESSAGE);
        logger.severe("Error de formato numérico: " + e.getMessage());
    }
    }//GEN-LAST:event_jButtonGuardarActionPerformed

    private void jButtonModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonModificarActionPerformed
    // Implementación de Actualizar (Update)
    int filaSeleccionada = jTableProductos.getSelectedRow();
    javax.swing.table.DefaultTableModel modelo = (javax.swing.table.DefaultTableModel) jTableProductos.getModel();

    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, "Debe seleccionar una fila para modificar.", "Error de Modificación", JOptionPane.WARNING_MESSAGE);
        return;
    }
    
    // 1. Obtener datos de los campos de texto
    // NO necesitamos obtener el código de texto para la validación, solo para el setEditable(false)
    String nombre = jTextFieldNombre.getText();
    String precioStr = jTextFieldPrecio.getText();
    String stockStr = jTextFieldStock.getText();
    
    // 2. Validación básica (NO validamos jTextFieldCodigo, ya que es el ID)
    if (nombre.isEmpty() || precioStr.isEmpty() || stockStr.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Todos los campos deben estar llenos para modificar.", "Error de Modificación", JOptionPane.ERROR_MESSAGE);
        return;
    }

    try {
        // Intentar parsear a tipos numéricos
        // Aquí no volvemos a obtener el código, lo leemos de la tabla (filaSeleccionada, 0) o simplemente lo ignoramos si no cambia.
        double precio = Double.parseDouble(precioStr);
        int stock = Integer.parseInt(stockStr);
        
        // 3. Actualizar los valores en la fila seleccionada. 
        // Nota: Mantenemos el código actual de la fila (columna 0), solo actualizamos el resto.
        // modelo.setValueAt(codigo, filaSeleccionada, 0); // No es necesario si no se modifica el código
        modelo.setValueAt(nombre, filaSeleccionada, 1);
        modelo.setValueAt(precio, filaSeleccionada, 2);
        modelo.setValueAt(stock, filaSeleccionada, 3);
        
        // 4. Notificar al usuario y limpiar campos
        JOptionPane.showMessageDialog(this, "Producto modificado exitosamente.", "Modificación Exitosa", JOptionPane.INFORMATION_MESSAGE);
        limpiarCampos();
        
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "El Precio y Stock deben ser números válidos.", "Error de Formato", JOptionPane.ERROR_MESSAGE);
        logger.severe("Error de formato numérico: " + e.getMessage());
    }
    }//GEN-LAST:event_jButtonModificarActionPerformed

    private void jButtonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEliminarActionPerformed
        // TODO add your handling code here:
        // Implementación de Eliminar (Delete)
    int filaSeleccionada = jTableProductos.getSelectedRow();

    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, "Debe seleccionar una fila para eliminar.", "Error de Eliminación", JOptionPane.WARNING_MESSAGE);
        return;
    }

    int confirmacion = JOptionPane.showConfirmDialog(this, 
            "¿Está seguro de que desea eliminar el producto seleccionado?", 
            "Confirmar Eliminación", 
            JOptionPane.YES_NO_OPTION);

    if (confirmacion == JOptionPane.YES_OPTION) {
        DefaultTableModel modelo = (DefaultTableModel) jTableProductos.getModel();

        // 1. Eliminar la fila del modelo
        modelo.removeRow(filaSeleccionada);

        // 2. Notificar al usuario y limpiar campos
        JOptionPane.showMessageDialog(this, "Producto eliminado exitosamente.", "Eliminación Exitosa", JOptionPane.INFORMATION_MESSAGE);
        limpiarCampos();
    }
    }//GEN-LAST:event_jButtonEliminarActionPerformed

    private void jButtonLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonLimpiarActionPerformed
        // TODO add your handling code here:
        // Implementación de Limpiar
        limpiarCampos();
    }//GEN-LAST:event_jButtonLimpiarActionPerformed

    private void jTextFieldCodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldCodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldCodigoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new CrudProductos().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnVolver;
    private javax.swing.JButton jButtonEliminar;
    private javax.swing.JButton jButtonGuardar;
    private javax.swing.JButton jButtonLimpiar;
    private javax.swing.JButton jButtonModificar;
    private javax.swing.JLabel jLabelCodigo;
    private javax.swing.JLabel jLabelNombre;
    private javax.swing.JLabel jLabelPrecio;
    private javax.swing.JLabel jLabelStock;
    private javax.swing.JLabel jLabelTitle;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableProductos;
    private javax.swing.JTextField jTextFieldCodigo;
    private javax.swing.JTextField jTextFieldNombre;
    private javax.swing.JTextField jTextFieldPrecio;
    private javax.swing.JTextField jTextFieldStock;
    // End of variables declaration//GEN-END:variables
}
